public interface RequiresShipping {
    String getName();
    double getWeight();
}